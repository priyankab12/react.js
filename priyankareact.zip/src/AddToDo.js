
import React from 'react';

const AddToDo = () => {
  return (
    <div>
      <label>Title</label>
      <input type="text" />
      <label>Description</label>
      <input type="text" />
      <button>Add ToDo</button>
    </div>
  );
};

export default AddToDo;