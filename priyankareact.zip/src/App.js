import React from "react";
import NavBar from "./NavBar";
import AddToDo from "./AddToDo";
const App = () => {
  return (
    <div>
      <NavBar />
      {/* <AddToDo /> */}
    </div>
  );
};

export default App;
